const scriptURL = "https://script.google.com/macros/s/AKfycbwwXFx6u8tvwnH1S2DTN0J6yK_dnXywifKYj62AiOPkOX3f5hbZWXUMke0UAoGGe1DbYg/exec"
const form = document.forms["contact-form"];
form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  fetch(scriptURL, { method: "POST", body: new FormData(form) })
    .then((response) => response.json())
    .then((data) => {
      if (data.result === "success") {
        alert("Thank you! Form is submitted");
        form.reset();
      } else {
        alert("Error: " + data.error);
      }
    })
    .catch((error) => console.error("Error!", error));
});